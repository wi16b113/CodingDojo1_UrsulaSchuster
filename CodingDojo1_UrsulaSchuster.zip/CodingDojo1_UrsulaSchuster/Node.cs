﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingDojo1_UrsulaSchuster
{
    class Node
    {
        public Item Data;

        public Node Next; //points at another node
    }
}
